#####################################################
#   Brought to you by the AFL Academic Free License
#   A copy of the license can be obtained in this
#   link http://www.opensource.org/licenses/AFL-3.0
#   
#
#   Author: Koloventzos Georgios
#
#   Department of Informatics
#      University of Athens
#             Hellas
#   
#   For suggestion and emails see here
#   http://cgi.di.uoa.gr/~std04250/contact.php
#   
#   Part of ErGA project http://erga.di.uoa.gr
#
#   The library uses the VPython library http://vpython.org/
#
#   
#####################################################

INSTALL

The only dependency of the library is th VPython.
You can download it form here: 
Windows: http://vpython.org/contents/download_windows.html
Mac OS: http://vpython.org/contents/download_mac.html
Linux: http://vpython.org/contents/download_linux.html

ALL Operating Systems Installation:
Open a terminal - cmd and run this in the directory
the unpacking created.

python setup.py install
